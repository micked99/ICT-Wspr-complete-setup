# ICT-PCB-v2-v5
Eagle PCB for v2-v5 of "my" version of the ICT hab board
This pcb is made and setup for sw versions v2-v5 of the the ict code

ict_v361-xs // using the QFN/MLF version of the 328 - Verified working                                                                                
ict_v361 // using the TQFP version of the 328 - untested
